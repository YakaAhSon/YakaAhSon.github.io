#include<glad/glad.h>
#include<math3d.h>
#include"bmpreader.h"
#include"my_shader.h"
#include<glfw/glfw3.h>
#include<vector>

#define dt 0.01667

int start = 0;
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods) {
	if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
		glfwSetWindowShouldClose(window, GLFW_TRUE);
	if (key == GLFW_KEY_0 && action == GLFW_PRESS)
		start = 1;
}

static void windowsize_callback(GLFWwindow* window, int width, int height) {
	glViewport(0, 0, width, height);
}

class Vertex {
public:
	M3DVector3f pos;
	M3DVector2f texCoord;
	// position predicted
	M3DVector3f pPos;
	// position in the last frame
	M3DVector2f oldPos;
	Vertex(float x,float y,float z, float tx,float ty) {
		pos[0] = x; pos[1] = y; pos[2] = z;
		oldPos[0] = x; oldPos[1] = y; oldPos[2] = z;
		texCoord[0] = tx; texCoord[1] = ty;
	}
	void predict() {
		static float wind_z = 0.0f;
		static M3DVector3f step;
		m3dSubtractVectors3(step, pos, oldPos);
		m3dAddVectors3(pPos, step, pos);
		static M3DVector3f gravity_wind = {
			1.0*0.5*dt*dt,-9.8*0.5*dt*dt,0.0
		};
		m3dAddVectors3(pPos, gravity_wind, pPos);
		// wind in z direction
		wind_z += 0.001;
		pPos[2] += 10*dt*dt*sin(wind_z);
		pPos[0]+= 3 * dt*dt*sin(0.1*wind_z);
		m3dSubtractVectors3(step, pPos, pos);
		// f = v*alpha
		// ds = 0.5*f*dt*dt = 0.5*v*alpha*dt*dt = 0.5* step/dt*alpha*dt*dt = 0.5*alpha*step*dt
		m3dScaleVector3(step, 0.5*1.0*dt);
		m3dSubtractVectors3(pPos, pPos, step);
	}
	void update() {
		m3dCopyVector3(oldPos, pos);
		m3dCopyVector3(pos, pPos);
	}
};

// constraint between vertexes
class Constraint {
public:
	Vertex *v1, *v2;
	Constraint(Vertex* _v1,Vertex* _v2) {
		v1 = _v1;
		v2 = _v2;
	}
	void satisfy() {
		static M3DVector3f sub;
		m3dSubtractVectors3(sub, v1->pPos, v2->pPos);
		float l = m3dGetVectorLength3(sub);
		if (l > 0.1) {
			m3dScaleVector3(sub, (l - 0.1)/l*0.5);
			m3dAddVectors3(v2->pPos, sub, v2->pPos);
			m3dSubtractVectors3(v1->pPos, v1->pPos,sub);
		}
	}
};

class Pin {
public:
	Vertex * v;
	M3DVector3f pos;
	Pin(Vertex* _v,float x,float y,float z) {
		v = _v;
		pos[0] = x; pos[1] = y; pos[2] = z;
	}
	void satisfy() {
		m3dCopyVector3(v->pPos, pos);
	}
};

// 11*11
Vertex* vertexes[11][11];
std::vector<Constraint*> constraints;
std::vector<Pin*>pins;
GLfloat vertexData[4800];

void initCloth() {
	for (int x = 0; x < 11; x++) {
		for (int y = 0; y < 11; y++) {
			float fx = x / 10.0f;
			float fy = y / 10.0f;
			vertexes[x][y] = new Vertex(fx, fy, 0.0f, fx, fy);
		}
	}
	// ����
	for (int x = 0; x < 11; x++) {
		for (int y = 0; y < 10; y++) {
			constraints.push_back(new Constraint(vertexes[x][y], vertexes[x][y + 1]));
		}
	}
	// ����
	for (int y = 0; y < 11; y++) {
		for (int x = 0; x < 10; x++) {
			constraints.push_back(new Constraint(vertexes[x][y], vertexes[x + 1][y]));
		}
	}
	/*
	for (int y = 0; y < 11; y++) {
		
		pins.push_back(new Pin(vertexes[0][y], 0.0, y*0.1, 0.0));
	}
	*/
	//pins.push_back(new Pin(vertexes[0][0], 0.0, 0.0, 0.0));
	pins.push_back(new Pin(vertexes[10][10], 1.0, 1.0, 0.0));
	pins.push_back(new Pin(vertexes[0][10], 0.0, 1.0, 0.0));
}

int vertexCount;
void addVertex(M3DVector3f vVertex,M3DVector3f vNormal,M3DVector2f vTexCoord) {
	memcpy(&(vertexData[vertexCount * 8]), vVertex, 3 * sizeof(GLfloat));
	memcpy(&(vertexData[vertexCount * 8 + 3]), vNormal , 3 * sizeof(GLfloat));
	memcpy(&(vertexData[vertexCount * 8 + 6]), vTexCoord, 2 * sizeof(GLfloat));
	vertexCount++;
}
void setupTriangle(Vertex* v1,Vertex* v2,Vertex* v3) {
	static M3DVector3f d1, d2, normal;
	m3dSubtractVectors3(d1, v1->pos, v2->pos);
	m3dSubtractVectors3(d2, v1->pos, v3->pos);
	float f1 = m3dGetVectorLength3(d1);
	float f2 = m3dGetVectorLength3(d2);
	if (f1*f2 < 0.00001) {
		normal[0] = 1.0f; normal[1] = 0.0f; normal[2] = 0.0f;
	}
	else {
		m3dCrossProduct3(normal, d1, d2);
		m3dNormalizeVector3(normal);
	}
	addVertex(v1->pos, normal, v1->texCoord);
	addVertex(v2->pos, normal, v2->texCoord);
	addVertex(v3->pos, normal, v3->texCoord);
}

void setupVertexData() {
	vertexCount = 0;
	for (int x = 0; x < 10; x++) {
		for (int y = 0; y < 10; y++) {
			setupTriangle(vertexes[x][y], vertexes[x + 1][y], vertexes[x][y + 1]);
			setupTriangle(vertexes[x + 1][y + 1], vertexes[x + 1][y], vertexes[x][y + 1]);
		}
	}
}

int main() {

	GLFWwindow* window;
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);
	glfwWindowHint(GLFW_SAMPLES, 4);
	window = glfwCreateWindow(512, 512, "cloth", NULL, NULL);
	glfwMakeContextCurrent(window);
	gladLoadGLLoader((GLADloadproc)glfwGetProcAddress);
	glfwSetKeyCallback(window, key_callback);

	glfwSetWindowSizeCallback(window, windowsize_callback);
	glfwSwapInterval(1);
	glClearColor(0.5, 0.5, 0.5, 1);

	shader::init();
	initCloth();

	glDisable(GL_CULL_FACE);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_MULTISAMPLE);

	GLuint vao, vbo;
	glGenVertexArrays(1, &vao);
	glBindVertexArray(vao);
	glGenBuffers(1, &vbo);
	glBindBuffer(GL_ARRAY_BUFFER, vbo);


	glBufferData(GL_ARRAY_BUFFER, sizeof(vertexData), NULL, GL_STATIC_READ);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), 0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (void*)(3 * sizeof(GLfloat)));
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (void*)(6 * sizeof(GLfloat)));

	M3DMatrix44f mView, mModel, mProjection;
	m3dLoadIdentity44(mView);
	m3dTranslationMatrix44(mModel, -0.5, 0.0, -5.0);
	m3dMakePerspectiveMatrix(mProjection, 0.5, 1.0, 1.0, 1000.0);

	shader::setModelMatrix(mModel);
	shader::setProjectionMatrix(mProjection);
	shader::setViewMatrix(mView);

	GLbyte* pBytes;
	int nWidth, nHeight;
	pBytes = gltReadBMPBits("texture.bmp", &nWidth, &nHeight);


	GLuint texture;
	glGenTextures(1, &texture);
	glBindTexture(GL_TEXTURE_2D, texture);
	
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, nWidth, nHeight, 0, GL_BGR, GL_UNSIGNED_BYTE, pBytes);
	glGenerateMipmap(GL_TEXTURE_2D);

	while (!glfwWindowShouldClose(window)) {
		if (start) {
			for (int i = 0; i < 11; i++) {
				for (int j = 0; j < 11; j++) {
					vertexes[i][j]->predict();
				}
			}
			for (auto i = pins.begin(); i != pins.end(); i++) {
				(*i)->satisfy();
			}
			for (auto i = constraints.begin(); i != constraints.end(); i++) {
				(*i)->satisfy();
			}
			for (auto i = constraints.begin(); i != constraints.end(); i++) {
				(*i)->satisfy();
			}
			for (auto i = pins.begin(); i != pins.end(); i++) {
				(*i)->satisfy();
			}
			for (int i = 0; i < 11; i++) {
				for (int j = 0; j < 11; j++) {
					vertexes[i][j]->update();
				}
			}
		}
		setupVertexData();
		glBufferData(GL_ARRAY_BUFFER, sizeof(vertexData), vertexData, GL_STATIC_READ);

		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glEnableVertexAttribArray(0);
		glEnableVertexAttribArray(1);
		glEnableVertexAttribArray(2);
		glDrawArrays(GL_TRIANGLES, 0, 200*3);

		glfwSwapBuffers(window);
		glfwPollEvents();
	}
	glfwTerminate();
	return 0;
}