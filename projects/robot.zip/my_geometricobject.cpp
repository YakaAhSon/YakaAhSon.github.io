#include"my_objectmanager.h"
#include<glad/glad.h>
#include<stdlib.h>
#include<math.h>
#include<iostream>
#define pi 3.1415926535898
GeometricObject::GeometricObject():GeometricCoordinate(),EnableFlag() {
	num_triangles = 0;
	num_vertexes = 0;
}

void GeometricObject::allocTempMemory() {
	tempMemory =  (GLfloat*)malloc(sizeof(GLfloat) * 3 * num_triangles * 6);
}
void GeometricObject::copyVertexData() {
	glGenVertexArrays(1, &vao);
	glBindVertexArray(vao);
	glGenBuffers(1, &vbo);
	glBindBuffer(GL_ARRAY_BUFFER, vbo);


	glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat) *num_vertexes*6,tempMemory,GL_STATIC_READ);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6*sizeof(GLfloat), 0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(GLfloat), (void*)(3 * sizeof(GLfloat)));
	free(tempMemory);
	glBindVertexArray(0);
}
void GeometricObject::addVertex(GLfloat x,GLfloat y,GLfloat z,GLfloat nx,GLfloat ny,GLfloat nz) {
	tempMemory[num_vertexes * 6] = x;
	tempMemory[num_vertexes * 6 + 1] = y;
	tempMemory[num_vertexes * 6 + 2] = z;
	tempMemory[num_vertexes * 6 + 3] = nx;
	tempMemory[num_vertexes * 6 + 4] = ny;
	tempMemory[num_vertexes * 6 + 5] = nz;
	num_vertexes++;
}

GeometricObject* GeometricObject::makeSphere(GLfloat r) {
	// Ĭ�Ͼ�γ�����ƽ���ֳ�10�ݣ���180��������
	return makeSphere(r, 10, 10);
}
GeometricObject* GeometricObject::makeSphere(GLfloat r,int p1,int p2) {
	// ���ȷ��򻮷�p1������
	// γ�ȷ��򻮷�p2������
	p1 = p1 < 4 ? 4 : p1;
	p2 = p2 < 2 ? 2 : p2;
	GeometricObject * rs = new GeometricObject();
	rs->num_triangles = p1*(p2-1)*2;
	rs->allocTempMemory();
	auto addSphereVertex = [=](GLfloat lgt, GLfloat lat)->void {
		GLfloat x = cos(lat)*cos(lgt);
		GLfloat y = cos(lat)*sin(lgt);
		GLfloat z = sin(lat);
		rs->addVertex(x*r, y*r, z*r, x, y, z);
	};
	for (int x = 0; x < p1; x++) {
		float lgt_low = x / float(p1) * 2 * pi;
		float lgt_high = (x + 1) / float(p1) * 2 * pi;
		addSphereVertex(0.0, -pi / 2);
		addSphereVertex(lgt_high, -pi / 2 + (1.0 / p2 * pi));
		addSphereVertex(lgt_low, -pi / 2 + (1.0 / p2 * pi));
		addSphereVertex(0.0, pi / 2);
		addSphereVertex(lgt_low, pi / 2 - (1.0 / p2 * pi));
		addSphereVertex(lgt_high, pi / 2 - (1.0 / p2 * pi));
		for (int y = 1; y < p2-1; y++) {
			float lat_low = y / float(p2)*pi - pi / 2;
			float lat_high = (y + 1) / float(p2)*pi - pi / 2;
			addSphereVertex(lgt_low, lat_low);
			addSphereVertex(lgt_high, lat_low);
			addSphereVertex(lgt_high, lat_high);
			addSphereVertex(lgt_low, lat_low);
			addSphereVertex(lgt_high, lat_high);
			addSphereVertex(lgt_low, lat_high);
		}
	}
	rs->copyVertexData();
	return rs;
}

GeometricObject* GeometricObject::makeCylinder(GLfloat r, GLfloat h) {
	return makeCylinder(r, h, 10);
}
GeometricObject* GeometricObject::makeCylinder(GLfloat r, GLfloat h, int p) {
	p = p < 4 ? 4 : p;
	GeometricObject* rs = new GeometricObject();
	rs->num_triangles = p * 4;
	rs->allocTempMemory();
	for (int i = 0; i < p; i++) {
		GLfloat lgt_low = i / float(p) * 2 * pi;
		GLfloat lgt_high = (i + 1) / float(p) * 2 * pi;
		GLfloat x_low = cos(lgt_low);
		GLfloat x_high = cos(lgt_high);
		GLfloat z_low = sin(lgt_low);
		GLfloat z_high = sin(lgt_high);
		// ����������
		rs->addVertex(0, 0, 0, 0, -1.0, 0);
		
		rs->addVertex(x_low*r, 0, z_low*r, 0, -1.0, 0);
		rs->addVertex(x_high*r, 0, z_high*r, 0, -1.0, 0);
		//	����������
		
		rs->addVertex(x_low*r, h, z_low*r, 0, 1.0, 0);
		rs->addVertex(0, h, 0, 0, 1.0, 0);
		rs->addVertex(x_high*r, h, z_high*r, 0, 1.0, 0);
		
		// ���泤����
		rs->addVertex(x_low*r, 0, z_low*r, x_low, 0, z_low);
		rs->addVertex(x_low*r, h, z_low*r, x_low, 0, z_low);
		rs->addVertex(x_high*r, 0, z_high*r, x_high, 0, z_high);

		rs->addVertex(x_high*r, h, z_high*r, x_high, 0, z_high);
		
		rs->addVertex(x_high*r, 0, z_high*r, x_high, 0, z_high);
		rs->addVertex(x_low*r, h, z_low*r, x_low, 0, z_low);
	}
	rs->copyVertexData();
	return rs;
}

GeometricObject* GeometricObject::makePlane(GLfloat l) {
	GeometricObject* rs = new GeometricObject();
	rs->num_triangles = 2;
	rs->allocTempMemory();
	rs->addVertex(-0.5*l, 0.0f, -0.5*l, 0.0f, 1.0f, 0.0f);
	rs->addVertex(0.5*l, 0.0f, -0.5*l, 0.0f, 1.0f, 0.0f);
	rs->addVertex(-0.5*l, 0.0f, 0.5*l, 0.0f, 1.0f, 0.0f);
	rs->addVertex(-0.5*l, 0.0f, 0.5*l, 0.0f, 1.0f, 0.0f);
	rs->addVertex(0.5*l, 0.0f, -0.5*l, 0.0f, 1.0f, 0.0f);
	rs->addVertex(0.5*l, 0.0f, 0.5*l, 0.0f, 1.0f, 0.0f);
	return rs;
}

void GeometricObject::draw() {
	if (!_enabled) {
		return;
	}
	static M3DMatrix44f m = {
		1,0,0,0,
		0,1,0,0,
		0,0,1,0,
		0,0,0,1
	};
	draw(m);
}
void GeometricObject::draw(M3DMatrix44f mGlobal) {
	if (!_enabled) {
		return;
	}
	M3DMatrix44f mModel, mFinal;
	getMModel(mModel);
	m3dMatrixMultiply44(mFinal, mGlobal, mModel);

	shader::setModelMatrix(mFinal);

	glBindVertexArray(vao);
	glEnableVertexAttribArray(0);
	glEnableVertexAttribArray(1);
	glDrawArrays(GL_TRIANGLES, 0, num_vertexes);
	glBindVertexArray(0);
}