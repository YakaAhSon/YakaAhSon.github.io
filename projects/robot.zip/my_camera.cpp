#include"my_objectmanager.h"
Camera::Camera() :GeometricCoordinate() {
}
void Camera::setViewFrustum(GLfloat fFov, GLfloat fAspect, GLfloat fNear, GLfloat fFar) {
	m3dMakePerspectiveMatrix(mProjection, fFov, fAspect, fNear, fFar);
}
M3DMatrix44f& Camera::projectionMatrix() {
	return mProjection;
}

M3DMatrix44f& Camera::viewMatrix() {
	static M3DMatrix44f mV;
	M3DMatrix44f temp;
	getMModel(temp);
	m3dInvertMatrix44(mV, temp);
	return mV;
}