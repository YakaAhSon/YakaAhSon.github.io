#include"my_objectmanager.h"
GeometricCoordinate::GeometricCoordinate() {
	reset();
}
void GeometricCoordinate::reset() {
	m3dLoadIdentity33(mRotation);
	vTranslation[0] = 0;
	vTranslation[1] = 0;
	vTranslation[2] = 0;
}


void GeometricCoordinate::globalRotation(GLfloat angle, GLfloat x, GLfloat y, GLfloat z) {
	static M3DMatrix33f temp1, temp2;
	m3dRotationMatrix33(temp1, angle, x, y, z);
	m3dMatrixMultiply33(temp2, mRotation, temp1);
	memcpy(mRotation, temp2, sizeof(GLfloat) * 9);
	static M3DVector3f tv;
	m3dRotateVector(tv, vTranslation, temp1);
	memcpy(vTranslation, tv, sizeof(float) * 3);
}

void GeometricCoordinate::globalTranslations(GLfloat x, GLfloat y, GLfloat z) {
	vTranslation[0] += x;
	vTranslation[1] += y;
	vTranslation[2] += z;
}

void GeometricCoordinate::localRotation(GLfloat angle, GLfloat x, GLfloat y, GLfloat z) {
	static M3DMatrix33f temp1, temp2;
	m3dRotationMatrix33(temp1, angle, x, y, z);
	m3dMatrixMultiply33(temp2, temp1, mRotation);
	memcpy(mRotation, temp2, sizeof(GLfloat) * 9);
}

void GeometricCoordinate::localTranslation(GLfloat x, GLfloat y, GLfloat z) {
	static M3DVector3f tv, temp;
	temp[0] = x;
	temp[1] = y;
	temp[2] = z;
	m3dRotateVector(tv, temp, mRotation);
	m3dAddVectors3(vTranslation, tv, vTranslation);
}
void GeometricCoordinate::relativeRotation(GLfloat angle, GLfloat x, GLfloat y, GLfloat z) {
	static M3DMatrix33f temp1, temp2;
	m3dRotationMatrix33(temp1, angle, x, y, z);
	m3dMatrixMultiply33(temp2, mRotation, temp1);
	memcpy(mRotation, temp2, sizeof(GLfloat) * 9);
}

void GeometricCoordinate::getMModel(M3DMatrix44f mModel) {
	m3dLoadIdentity44(mModel);
	memcpy(mModel, mRotation, 3 * sizeof(float));
	memcpy(&mModel[4], &mRotation[3], 3 * sizeof(float));
	memcpy(&mModel[8], &mRotation[6], 3 * sizeof(float));
	memcpy(&mModel[12], vTranslation, 3 * sizeof(float));
}
