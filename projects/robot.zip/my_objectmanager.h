// geometric objects
#ifndef __OBJECT_MANAGER__
#define __OBJECT_MANAGER__
#include<glad/glad.h>
#include<math3d.h>
#include<set>
#include"my_shader.h"

class EnableFlag {
public:
	int _enabled;
public:
	EnableFlag() {
		_enabled = 1;
	}
	void enable() {
		_enabled = 1;
	}
	void disable() {
		_enabled = 0;
	}
};
class GeometricCoordinate {
private:
	// mModel = mTranslation*mRotation������ת��ƽ��
	M3DMatrix33f mRotation;
	// mModel = mTranslation*mRotation������ת��ƽ��
	M3DVector3f vTranslation;
public:
	GeometricCoordinate();
	// ���������ϵ����ת(����)
	void globalRotation(GLfloat angle, GLfloat x, GLfloat y, GLfloat z);
	// ���������ϵ��ƽ��
	void globalTranslations(GLfloat x, GLfloat y, GLfloat z);
	// �ڱ�������ϵ����ת
	void localRotation(GLfloat angle, GLfloat x, GLfloat y, GLfloat z);
	// �ڱ�������ϵ��ƽ��
	void localTranslation(GLfloat x, GLfloat y, GLfloat z);
	// ��ƽ���涯����ϵ����ת
	void relativeRotation(GLfloat angle, GLfloat x, GLfloat y, GLfloat z);
	void getMModel(M3DMatrix44f mModel);
	void reset();
	void resetRotation() {
		m3dLoadIdentity33(mRotation);
	}
};

class GeometricObject :public GeometricCoordinate,EnableFlag {
private:
	GLuint vao;
	GLuint vbo;
	GLuint num_triangles;
	GLuint num_vertexes;
	void allocTempMemory();
	GLfloat* tempMemory;
	void addVertex(GLfloat x,GLfloat y,GLfloat z,GLfloat nx,GLfloat ny,GLfloat nz);
	void copyVertexData();
public:
	GeometricObject();
	// ������(0,0,0)������
	static GeometricObject* makeSphere(GLfloat r);
	static GeometricObject* makeSphere(GLfloat r,int p1,int p2);
	// ����Բ����(0,0,0),������y���Բ����
	static GeometricObject* makeCylinder(GLfloat r, GLfloat h);
	static GeometricObject* makeCylinder(GLfloat r,GLfloat h,int p);
	static GeometricObject* makePlane(GLfloat l);
	void draw();
	void draw(M3DMatrix44f mGlocal);
};

class GeometricGroup:public GeometricCoordinate,EnableFlag {
private:
	std::set<GeometricGroup*> groups;
	std::set<GeometricObject*>objects;
public:
	GeometricGroup();
	void addGroup(GeometricGroup* g);
	void addObject(GeometricObject* o);
	void draw();
	void draw(M3DMatrix44f mGlobal);
};
class Camera :public GeometricCoordinate {
private:
	M3DMatrix44f mProjection;
public:
	Camera();
	void setViewFrustum(GLfloat fFov,GLfloat fAspect,GLfloat fNear,GLfloat fFar);
	M3DMatrix44f& projectionMatrix();
	M3DMatrix44f& viewMatrix();
	
};

class Scene {
private:
	std::set<GeometricGroup*>groups;
	std::set<GeometricObject*>objects;
public:
	Camera camera;
	Scene();
	void addGroup(GeometricGroup* g) {
		groups.insert(g);
	}
	void addObject(GeometricObject* o) {
		objects.insert(o);
	}
	void setLight(GLfloat x, GLfloat y, GLfloat z);
	void draw();
};
#endif