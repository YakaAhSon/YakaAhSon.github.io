#include"my_shader.h"
using namespace shader;
const char* vss = "#version 430\n"
"uniform mat4 mProjection;\n"
"uniform mat4 mModel;\n"
"uniform mat4 mView;\n"
"in vec3 vVertex;\n"
"in vec3 vNormal;\n"
"out vec3 varyingVNormal;\n"
"void main(void){\n"
"	gl_Position = mProjection*mView*mModel*vec4(vVertex,1.0);\n"
"	mat4 mRotate = mModel;\n"
"	mRotate[3] = vec4(0,0,0,1);\n"
"	varyingVNormal = (mRotate*vec4(vNormal,1.0)).xyz;\n"
"}";
const char* fss = "#version 430\n"
"uniform vec3 vLight;\n"
"in vec3 varyingVNormal;\n"
"void main(void){\n"
"	float color = (0.35+dot(varyingVNormal,vLight)/1.5);\n"
"	gl_FragColor = vec4(color,color,color,1);\n"
"}";
GLuint program;
GLuint loc_model, loc_view, loc_projection, loc_light;
void shader::init() {
	program = glCreateProgram();
	GLuint vs = glCreateShader(GL_VERTEX_SHADER);
	GLuint fs = glCreateShader(GL_FRAGMENT_SHADER);
	int l = strlen(vss);
	glShaderSource(vs, 1, &vss, &l);
	glCompileShader(vs);
	l = strlen(fss);
	glShaderSource(fs, 1, &fss, &l);
	glCompileShader(fs);

	glAttachShader(program, vs);
	glAttachShader(program, fs);
	glBindAttribLocation(program, 0, "vVertex");
	glBindAttribLocation(program, 1, "vNormal");
	glLinkProgram(program);
	glUseProgram(program);
	loc_model = glGetUniformLocation(program, "mModel");
	loc_view = glGetUniformLocation(program, "mView");
	loc_projection = glGetUniformLocation(program, "mProjection");
	loc_light = glGetUniformLocation(program, "vLight");
	setParrelLight(0.57735, 0.57735, 0.57735);
}

void shader::setParrelLight(GLfloat x, GLfloat y, GLfloat z) {
	static M3DVector3f light;
	light[0] = x;
	light[1] = y;
	light[2] = z;
	glUniform3fv(loc_light, 1, light);
}
void shader::setViewMatrix(M3DMatrix44f m) {
	glUniformMatrix4fv(loc_view, 1, GL_FALSE, m);
}
void shader::setModelMatrix(M3DMatrix44f m) {
	glUniformMatrix4fv(loc_model, 1, GL_FALSE, m);
}
void shader::setProjectionMatrix(M3DMatrix44f m) {
	glUniformMatrix4fv(loc_projection, 1, GL_FALSE, m);
}