#include"my_objectmanager.h"
#include<set>

void GeometricGroup::addGroup(GeometricGroup* g) {
	groups.insert(g);
}
void GeometricGroup::addObject(GeometricObject* o) {
	objects.insert(o);

}
GeometricGroup::GeometricGroup():GeometricCoordinate(),EnableFlag() {
	groups.clear();
	objects.clear();
}
void GeometricGroup::draw() {
	if (!_enabled) {
		return;
	}
	static M3DMatrix44f m = {
		1,0,0,0,
		0,1,0,0,
		0,0,1,0,
		0,0,0,1
	};
	draw(m);
}
void GeometricGroup::draw(M3DMatrix44f mGlobal) {
	if (!_enabled) {
		return;
	}
	M3DMatrix44f mModel, mFinal;
	getMModel(mModel);
	m3dMatrixMultiply44(mFinal, mGlobal, mModel);

	for (auto i = groups.begin(); i != groups.end(); i++) {
		(*i)->draw(mFinal);
	}
	for (auto i = objects.begin(); i != objects.end(); i++) {
		(*i)->draw(mFinal);
	}
}