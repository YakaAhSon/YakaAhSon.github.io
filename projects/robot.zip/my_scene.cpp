#include"my_objectmanager.h"
Scene::Scene() {
	camera.reset();
	groups.clear();
	objects.clear();
}
void Scene::setLight(GLfloat x, GLfloat y, GLfloat z) {
	shader::setParrelLight(x, y, z);
}
void Scene::draw() {
	shader::setViewMatrix(camera.viewMatrix());
	shader::setProjectionMatrix(camera.projectionMatrix());
	for (auto i = groups.begin(); i != groups.end(); i++) {
		(*i)->draw();
	}
	for (auto i = objects.begin(); i != objects.end(); i++) {
		(*i)->draw();
	}
}