/*A robot, can be controled by keyboard*/
#include<glad/glad.h>
#include"my_objectmanager.h"

#include<math3d.h>
#include<glfw/glfw3.h>


#include<iostream>

#define pi 3.1415926


Scene scene;
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods) {
	if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
		glfwSetWindowShouldClose(window, GLFW_TRUE);
	if (key == GLFW_KEY_UP)
		scene.camera.globalTranslations(0, 0, -1.0);

}

static void windowsize_callback(GLFWwindow* window, int width, int height) {
	glViewport(0, 0, width, height);
}
int main(){
GLFWwindow* window;
glfwInit();
glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);
glfwWindowHint(GLFW_SAMPLES, 4);
window = glfwCreateWindow(512, 512, "robot", NULL, NULL);
glfwMakeContextCurrent(window);
gladLoadGLLoader((GLADloadproc)glfwGetProcAddress);
glfwSetKeyCallback(window, key_callback);

glfwSetWindowSizeCallback(window, windowsize_callback);
glfwSwapInterval(1);
glClearColor(0.5, 0.5, 0.5, 1);
shader::init();

glEnable (GL_CULL_FACE);
glCullFace(GL_CCW);
glEnable(GL_DEPTH_TEST);
glEnable(GL_MULTISAMPLE);


Scene scene;scene.camera.setViewFrustum(1.5, 1.0, 1.0, 1000.0);
scene.camera.globalTranslations(0.0f, 0.0f, 2.0f);

GeometricGroup* robot = new GeometricGroup();
GeometricObject* trunk = GeometricObject::makeCylinder(0.18, 0.5,20);
robot->addObject(trunk);

GeometricObject* head = GeometricObject::makeSphere(0.2, 20, 20);
head->globalTranslations(0.0, 0.75, 0.0);
robot->addObject(head);

GeometricGroup* leg_left = new GeometricGroup();
leg_left->globalRotation(pi, 1.0, 0.0, 0.0);
leg_left->localTranslation(0.12, 0.0, 0.0);
robot->addGroup(leg_left);
GeometricObject* leg_left_1 = GeometricObject::makeCylinder(0.08, 0.4);
leg_left->addObject(leg_left_1);
GeometricObject* leg_left_2 = GeometricObject::makeCylinder(0.08, 0.4);
leg_left_2->localTranslation(0.0, 0.41, 0.0);
leg_left->addObject(leg_left_2);

GeometricGroup* leg_right = new GeometricGroup();
leg_right->globalRotation(pi, 1.0, 0.0, 0.0);
leg_right->localTranslation(-0.12, 0.0, 0.0);
robot->addGroup(leg_right);
GeometricObject* leg_right_1 = GeometricObject::makeCylinder(0.08, 0.4);
leg_right->addObject(leg_right_1);
GeometricObject* leg_right_2 = GeometricObject::makeCylinder(0.08, 0.4);
leg_right_2->localTranslation(0.0, 0.41, 0.0);
leg_right->addObject(leg_right_2);

GeometricGroup* arm_left = new GeometricGroup();
arm_left->globalRotation(pi, 1.0, 0.0, 0.0);
arm_left->globalTranslations(0.25, 0.5, 0.0);
robot->addGroup(arm_left);
GeometricObject* arm_left_1 = GeometricObject::makeCylinder(0.05, 0.32);
arm_left->addObject(arm_left_1);
GeometricObject* arm_left_2 = GeometricObject::makeCylinder(0.05, 0.32);
arm_left_2->localTranslation(0.0, 0.33, 0.0);
arm_left->addObject(arm_left_2);

GeometricGroup* arm_right = new GeometricGroup();
arm_right->globalRotation(pi, 1.0, 0.0, 0.0);
arm_right->globalTranslations(-0.25, 0.5, 0.0);
robot->addGroup(arm_right);
GeometricObject* arm_right_1 = GeometricObject::makeCylinder(0.05, 0.32);
arm_right->addObject(arm_right_1);
GeometricObject* arm_right_2 = GeometricObject::makeCylinder(0.05, 0.32);
arm_right_2->localTranslation(0.0, 0.33, 0.0);
arm_right->addObject(arm_right_2);

scene.addGroup(robot);
robot->globalRotation(0.15, 1.0, 0.0, 0.0);


scene.camera.globalRotation(-0.8, 0.0, 1.0, 0.0);
scene.camera.globalTranslations(0.0, 0.3, 0.0);

while (!glfwWindowShouldClose(window)) {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	unsigned int t = GetTickCount();
	float f = t / 800.0*2*pi;

	arm_left->resetRotation();
	arm_left->relativeRotation(pi+sin(f)*0.5, 1.0, 0.0, 0.0);
	arm_left_2->resetRotation();
	arm_left_2->relativeRotation(0.5-pi/2 + 0.5*sin(f), 1.0, 0.0, 0.0);

	arm_right->resetRotation();
	arm_right->relativeRotation(pi + sin(f+pi)*0.5, 1.0, 0.0, 0.0);
	arm_right_2->resetRotation();
	arm_right_2->relativeRotation(0.5 - pi / 2 + 0.5*sin(f+pi), 1.0, 0.0, 0.0);

	leg_left->resetRotation();
	leg_left->relativeRotation(pi + sin(f+pi)*0.7 -0.3, 1.0, 0.0, 0.0);
	leg_left_2->resetRotation();
	leg_left_2->relativeRotation(sin(f+pi)*0.7 + 0.7,1.0,0.0,0.0);

	leg_right->resetRotation();
	leg_right->relativeRotation(pi + sin(f)*0.7 - 0.3, 1.0, 0.0, 0.0);
	leg_right_2->resetRotation();
	leg_right_2->relativeRotation(sin(f)*0.7 + 0.7, 1.0, 0.0, 0.0);
	robot->globalTranslations(0.0, 0.02*sin(2*f), 0.0);

	scene.camera.globalRotation(0.01, 0.0, 1.0, 0.0);

	scene.draw();

	glfwSwapBuffers(window);
	glfwPollEvents();
}
glfwTerminate();
}
