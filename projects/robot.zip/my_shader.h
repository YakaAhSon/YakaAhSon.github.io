#ifndef __MY_SHADER__
#define __MY_SHADER__
#include<glad/glad.h>
#include<math3d.h>
// ģ��̶�����
// Phong��ɫ
namespace shader {
	
	void init();
	void setParrelLight(GLfloat x,GLfloat y,GLfloat z);
	void setModelMatrix(M3DMatrix44f mModel);
	void setViewMatrix(M3DMatrix44f mView);
	void setProjectionMatrix(M3DMatrix44f mProjection);
}
#endif